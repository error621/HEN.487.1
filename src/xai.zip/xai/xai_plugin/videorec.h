
extern "C" int _videorec_export_function_video_rec(void);
extern "C" int _videorec_export_function_klicensee(void);
extern "C" int _videorec_export_function_secureid(void);
extern "C" int _videorec_export_function_sfoverride(void);