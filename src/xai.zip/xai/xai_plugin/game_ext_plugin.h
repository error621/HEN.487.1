// Mysis game_ext_plugin.h v0.1
class game_ext_plugin_interface
{
public:
	int (*DoUnk0)();
	int (*DoUnk1)(void *, void *);
	int (*DoUnk2)(char *, int, int);
	int (*DoUnk3)(char *, int);
	int (*DoUnk4)(char *, char *, int, int);
	int (*DoUnk5)(char *, int, char *, int);
	int (*DoUnk6)(void *);
	int (*DoUnk7)(int,int,void*);
	int (*DoUnk8)();
	int (*DoUnk9)(int, char*, void*,void*);
	int (*DoUnk10)(int , void* , void * );
	int (*DoUnk11)(int, int, void*, void*);
	int (*DoUnk12)(void*);
	int (*DoUnk13)(char*, char*);
	int (*DoUnk14)(char*);
	int (*DoUnk15)();
	int (*DoUnk16)(char*);
	int (*DoUnk17)(char*);
	int (*DoUnk18)();
	int (*DoUnk19)(void*);
	int (*DoUnk20)(char*,int, char*);
	int (*DoUnk21)(char*,int,char*);
	int (*DoUnk22)(char*,int,char*);
	int (*DoUnk23)(int,char*,int);
	int (*DoUnk24)(int,int);
	int (*DoUnk25)(void*);
	int (*DoUnk26)(void*);
	int (*DoUnk27)(void*);
	int (*DoUnk28)(int*,char*);
	int (*DoUnk29)(void*,char*);
	int (*DoUnk30)();
	int (*DoUnk31)(); 
	int (*DoUnk32)(void*,char*,void*,int);
	int (*DoUnk33)(char*);
	int (*DoUnk34)(char*);
}; 
